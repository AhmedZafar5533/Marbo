import { motion } from "framer-motion";
import {
  FaUserPlus,

  FaGlobeAfrica,
  FaStore,
  FaCreditCard,
  FaUserCheck,
  FaHandshake,

} from "react-icons/fa";
import { useEffect, useRef, useState } from "react";

const colors = {
  primary: '#E50000',       // Rich vibrant red
  secondary: '#FFCC00',     // Bold yellow
  accent: '#ec5f4f',        // Add this line - using the same accent from desktop
  background: '#FFFFFF',    // Clean white
  darkBackground: '#222222', // Near black for contrast
  text: '#333333',          // Dark text for readability
  lightText: '#FFFFFF',     // White text for dark backgrounds
  accentGrey: '#F6F6F6'     // Light grey for subtle backgrounds
};

const steps = [
  {
    title: "Global Connection Hub",
    description:
      "MarboGlobal bridges continents, connecting diasporans worldwide with trusted providers from home—bringing distant services right to your fingertips.",
    icon: <FaGlobeAfrica />,
    category: "global network",
    color: colors.primary,
  },
  {
    title: "Quick Seamless Registration",
    description:
      "Join in minutes! Whether you're abroad seeking home services or a provider ready to expand globally, our streamlined signup process gets you connected instantly.",
    icon: <FaUserPlus />,
    category: "easy access",
    color: colors.primary,
  },
  {
    title: "Verified & Trusted Partners",
    description:
      "Shop with confidence through our rigorous verification system—every provider is thoroughly vetted for quality, reliability, and authentic service delivery.",
    icon: <FaUserCheck />,
    category: "security",
    color: colors.primary,
  },
  {
    title: "Personalized Service Selection",
    description:
      "Browse, compare, and select from an extensive marketplace of home-based services and products—all customized to meet your specific needs and preferences.",
    icon: <FaStore />,
    category: "marketplace",
    color: colors.primary,
  },
  {
    title: "Direct Payments, No Middlemen",
    description:
      "Pay service providers directly with our secure payment system—eliminating extra fees and ensuring your money reaches the right hands every time.",
    icon: <FaCreditCard />,
    category: "transactions",
    color: colors.primary,
  },
  {
    title: "Family-Assisted Purchasing",
    description:
      "Enable loved ones back home to select items while you handle payment from abroad—perfect for gifts, necessities, and supporting family from a distance.",
    icon: <FaHandshake />,
    category: "collaboration",
    color: colors.primary,
  },
];

const HowItWorks = () => {
  const pathRef = useRef(null);
  const containerRef = useRef(null);
  const [isMobile, setIsMobile] = useState(false);
  const [activeStep, setActiveStep] = useState(null);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => {
      window.removeEventListener("resize", checkMobile);
    };
  }, [isMobile]);


  const getStepBackgroundColor = (step, index) => {
    const baseColor = step.color || colors.primary;
    return `${baseColor}${activeStep === index ? '20' : '10'}`;
  };

  return (
    <section
      className="relative py-10 md:mb-45 md:py-10 px-4 md:px-8 "
      ref={containerRef}
      
    >


      <div className="relative max-w-7xl mx-auto ">
        {/* Header section */}
        <div className="text-center mb-16 relative ">
          <motion.div
            className="inline-block font-semibold mb-2 px-4 py-1 rounded-full"
            style={{
              backgroundColor: `${colors.primary}20`,
              color: colors.primary
            }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            viewport={{ once: true }}
          >
            Simple Process, Powerful Results
          </motion.div>

          <motion.h2
            className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 relative"
            style={{ color: colors.text }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            viewport={{ once: true }}
          >
            How Marbo Global Works
          </motion.h2>

          <motion.p
            className="max-w-2xl mx-auto text-lg"
            style={{ color: `${colors.text}CC` }}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
          >
            Our streamlined marketplace connects vendors and buyers through an intuitive platform designed for global commerce.
          </motion.p>
        </div>

        {/* Desktop curved path layout */}
        {!isMobile && (
          <div className="relative max-w-full md:max-w-[1100px] h-[1600px] mx-auto hidden md:block">
            <svg
              className="absolute top-0 left-0 w-full h-full z-[1]"
              viewBox="0 0 1000 1600"
              preserveAspectRatio="none"
            >
              <defs>
                <linearGradient id="pathGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor={colors.primary} stopOpacity="0.8" />
                  <stop offset="100%" stopColor={colors.accent} stopOpacity="0.6" />
                </linearGradient>
                <filter id="glow">
                  <feGaussianBlur stdDeviation="4" result="blur" />
                  <feComposite in="SourceGraphic" in2="blur" operator="over" />
                </filter>
              </defs>
              <path
                ref={pathRef}
                d="M500,0 C650,220 350,440 500,660 C650,880 350,1100 500,1320 C650,1540 500,1600 500,1600"
                fill="none"
                stroke="url(#pathGradient)"
                strokeWidth="4"
                strokeDasharray="10,10"
                className="stroke-linecap-round"
                filter="url(#glow)"
              />
            </svg>

            {/* Steps along the curved path */}
            <div className="relative h-full w-full z-[3]">
              {steps.map((step, index) => {
                const position = (index / (steps.length - 1)) * 100;
                const isLeft = index % 2 === 0;

                return (
                  <motion.div
                    className={`
                    absolute w-[300px] md:w-[420px] flex items-center transition-all duration-300 ease-in-out 
                    rounded-2xl
                    ${isLeft ? 'left-[10px] md:left-[40px]' : 'right-[10px] md:right-[40px]'} 
                    ${isLeft ? 'flex-row' : 'flex-row-reverse'}
                  `}
                    key={index}
                    style={{ top: `${position}%` }}
                    initial={{
                      opacity: 0,
                      x: isLeft ? -100 : 100, 
                      scale: 0.8
                    }}
                    whileInView={{
                      opacity: 1,
                      x: 0,
                      scale: 1
                    }}
                    transition={{
                      duration: 0.8,
                      delay: index * 0.15,
                      type: "spring",
                      stiffness: 50
                    }}
                    onMouseEnter={() => setActiveStep(index)}
                    onMouseLeave={() => setActiveStep(null)}
                    viewport={{ once: true, margin: "-100px" }}
                  >
                    {/* Step number */}
                    <div
                      className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full font-bold text-sm z-20"
                      style={{
                        backgroundColor: `${colors.accent}40`,
                        color: colors.text
                      }}
                    >
                      {index + 1}
                    </div>

                    {/* Icon container */}
                    <div className="flex-shrink-0 relative z-10">
                      <motion.div
                        className={`
                        w-[70px] h-[70px] md:w-[90px] md:h-[90px] flex items-center justify-center 
                        rounded-full text-2xl md:text-3xl text-white 
                        shadow-lg z-[2] mx-[10px] md:mx-[20px]
                      `}
                        style={{
                          background: 'linear-gradient(to right, #FD1A03,#ec5f4f) ',
                          boxShadow: `0 10px 30px -5px ${step.color}90`
                        }}
                        whileHover={{
                          scale: 1.1,
                          transition: { duration: 0.3 }
                        }}
                        animate={{
                          boxShadow: activeStep === index
                            ? [`0 0 20px 5px ${step.color}60`, `0 15px 35px -5px ${step.color}90`]
                            : `0 10px 30px -5px ${step.color}80`
                        }}
                      >
                        {step.icon}
                      </motion.div>
                    </div>

                    {/* Content card */}
                    <motion.div
                      className="
                      bg-white p-6 md:p-8 rounded-2xl shadow-xl 
                      flex-grow backdrop-blur-sm 
                      border
                      relative overflow-hidden
                    "
                      style={{
                        borderColor: `${colors.primary}20`
                      }}
                      animate={{
                        boxShadow: activeStep === index
                          ? `0 20px 50px -10px ${colors.primary}30`
                          : `0 10px 30px -5px ${colors.primary}15`
                      }}
                      whileHover={{
                        scale: 1.03,
                        transition: { duration: 0.3 }
                      }}
                    >
                      {/* Category badge */}
                      <div
                        className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-medium capitalize"
                        style={{
                          backgroundColor: `${colors.accent}40`,
                          color: colors.text
                        }}
                      >
                        {step.category}
                      </div>

                      <h3
                        className="relative z-10 text-[1.3rem] md:text-[1.6rem] font-bold mb-3 md:mb-4 mt-4"
                        style={{ color: colors.text }}
                      >
                        {step.title}
                      </h3>
                      <p
                        className="relative z-10 text-[0.95rem] md:text-[1.05rem] leading-[1.6] md:leading-[1.8]"
                        style={{ color: `${colors.text}CC` }}
                      >
                        {step.description}
                      </p>
                    </motion.div>
                  </motion.div>
                );
              })}
            </div>


          </div>
        )}

        {/* Mobile vertical timeline layout */}
        {isMobile && (
          <div className="max-w-[95%] mx-auto md:hidden">
            <div className="relative">
              {/* Vertical line with gradient */}

              {steps.map((step, index) => (
                <motion.div
                  key={index}
                  className="relative z-[2] mb-12 flex flex-col items-center"
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true, margin: "-50px" }}
                  onTouchStart={() => setActiveStep(index)}
                  onTouchEnd={() => setActiveStep(null)}
                >
                  {/* Step number */}
                  <div
                    className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full font-bold text-sm z-20"
                    style={{
                      backgroundColor: `${colors.accent}40`,
                      color: colors.text
                    }}
                  >
                    {index + 1}
                  </div>

                  {/* Icon */}
                  <motion.div
                    className="w-20 h-20 rounded-full flex items-center justify-center text-white text-2xl mb-6 z-[3]"
                    style={{
                      background: `linear-gradient(135deg, ${step.color}, ${colors.accent})`,
                      boxShadow: `0 8px 25px -4px ${step.color}80`
                    }}
                    whileHover={{ scale: 1.1 }}
                    animate={{
                      boxShadow: activeStep === index
                        ? [`0 0 20px 5px ${step.color}60`, `0 15px 35px -5px ${step.color}90`]
                        : `0 8px 25px -4px ${step.color}80`
                    }}
                  >
                    {step.icon}
                  </motion.div>

                  {/* Content Card */}
                  <motion.div
                    className="bg-white p-6 rounded-xl w-full shadow-lg"
                    style={{
                      background: `linear-gradient(to bottom right, white, ${getStepBackgroundColor(step, index)})`,
                      borderColor: `${colors.primary}20`
                    }}
                    whileHover={{ y: -5 }}
                    animate={{
                      boxShadow: activeStep === index
                        ? `0 20px 50px -10px ${colors.primary}30`
                        : `0 10px 30px -5px ${colors.primary}15`
                    }}
                  >
                    {/* Category badge */}
                    <div
                      className="mb-3 inline-block px-3 py-1 rounded-full text-xs font-medium capitalize"
                      style={{
                        backgroundColor: `${colors.accent}40`,
                        color: colors.text
                      }}
                    >
                      {step.category}
                    </div>

                    <h3
                      className="text-xl font-bold mb-3"
                      style={{ color: colors.text }}
                    >
                      {step.title}
                    </h3>
                    <p
                      className="leading-relaxed"
                      style={{ color: `${colors.text}CC` }}
                    >
                      {step.description}
                    </p>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </div>
        )}


      </div>
    </section>
  );
};

export default HowItWorks;